<?php

namespace BlessingSkin\AuthService\Controllers;

use App\Http\Controllers\Controller as BaseController;

class Controller extends BaseController
{
    //
}
